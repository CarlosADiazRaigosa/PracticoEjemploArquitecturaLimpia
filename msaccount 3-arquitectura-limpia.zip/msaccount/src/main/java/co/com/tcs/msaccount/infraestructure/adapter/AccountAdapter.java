package co.com.tcs.msaccount.infraestructure.adapter;

import co.com.tcs.msaccount.model.Account;
import co.com.tcs.msaccount.model.AccountGateway;
import lombok.Builder;

import java.util.List;

@Builder
public class AccountAdapter implements AccountGateway {
    @Override
    public Account getById(String type, long number) {
        // Ir por la info a la base de datos
        //return null;
        return Account.builder()
                .type(type)
                .number(number)
                .state(true)
                .balance(99000)
                .build();
    }

    @Override
    public List<Account> getAll() {
        return null;
    }

    @Override
    public List<Account> getByType(String type) {
        return null;
    }

    @Override
    public boolean create(Account account) {
        return false;
    }

    @Override
    public boolean update(Account account) {
        return false;
    }

    @Override
    public boolean delete(String type, long number) {
        return false;
    }

    @Override
    public boolean deleteAll() {
        return false;
    }
}
