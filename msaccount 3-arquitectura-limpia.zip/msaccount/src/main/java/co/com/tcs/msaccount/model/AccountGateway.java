package co.com.tcs.msaccount.model;

import java.util.List;

public interface AccountGateway {
    public Account getById(String type, long number);
    public List<Account> getAll();
    public List<Account> getByType(String type);
    public boolean create(Account account);
    public boolean update(Account account);
    public boolean delete(String type, long number);
    public boolean deleteAll();
}
